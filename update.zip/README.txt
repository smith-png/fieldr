Fieldr update: SVG sport art + shorter cards on mobile
UI only. Nothing under supabase/ changed.

NEW
  src/components/home/SportArt.tsx
    Cricket, futsal and volleyball SVG scenes. Each one builds once when its
    card scrolls into view (lines draw, stumps rise, ball drops in), then
    stays still. No looping animation. Reduced-motion shows the finished art.

CHANGED
  src/components/home/SportCardsGrid.tsx
    Photos replaced by SVG art. Card text (hairline, name, count) builds in
    after the art, one card after another. Phone height roughly 380px -> 180px.
  src/pages/public/RostersPage.tsx
    Same art and build-in. Phone image strip is shorter (16:7).
  src/components/roster/RosterPlayerCard.tsx
    Slightly tighter padding on phones only.
  src/index.css
    Animation rules appended at the end of the file (the .sa and .sa-card block).

HOW TO APPLY
  Extract over the project root, keep the folder structure, commit, push.
  Vercel redeploys on push. To roll back, use Vercel: Promote to Production.

NOT TOUCHED
  public/images/rosters/*.jpg are no longer used by these two pages.
  Delete them later if you like. Keeping them is harmless.
